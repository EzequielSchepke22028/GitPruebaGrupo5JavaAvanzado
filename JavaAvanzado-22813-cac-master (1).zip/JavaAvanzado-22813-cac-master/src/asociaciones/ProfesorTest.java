package asociaciones;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import junit.framework.Assert;

class ProfesorTest {

	@Test
	void test() {
		//fail("Not yet implemented");
		assertEquals(1, 1);
	}

}
