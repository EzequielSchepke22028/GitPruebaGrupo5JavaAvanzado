
public class Perro extends Mascota {

	public Perro(String nombre, Boolean esMamifero, String color, String especie) {
		super(nombre, esMamifero, color, especie);
		// TODO Auto-generated constructor stub
	}
	
	public String comunicarse() {
		return "Guau";
	}
	
}
